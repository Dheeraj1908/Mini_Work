const btn2 = document.getElementById('btn2');

btn2.addEventListener('mouseover',handleMouseOver);
btn2.addEventListener('mouseout',handleMouseOut);

function handleMouseOver(){
    btn2.style.backgroundColor='yellow';
    btn2.style.color='black';
}

function handleMouseOut(){
    btn2.style.backgroundColor='white';
    btn2.style.color='black';
}
